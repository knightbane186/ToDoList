//
//  CoreDataManager.swift
//  ToDoList app
//
//  Created by Denver Lopes on 14/2/2023.
//

import Foundation

import CoreData

class CoreDataManager{
    let persistentContainer: NSPersistentContainer
    static let shared: CoreDataManager = CoreDataManager()
    
    private init() {
        
        persistentContainer = NSPersistentContainer(name: "ToDoModel")
        //Creating a error block to catch any issue with the initialization.
        persistentContainer.loadPersistentStores{description, error in
            if let error = error {
                fatalError("Unable to initialize Core Data \(error)")
            }
        }
        
    }
    
}
