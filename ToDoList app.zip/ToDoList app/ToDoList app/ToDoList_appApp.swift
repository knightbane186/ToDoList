//
//  ToDoList_appApp.swift
//  ToDoList app
//
//  Created by Denver Lopes on 14/2/2023.
//

import SwiftUI
//import CoreData

@main
struct ToDoList_appApp: App {
  
    let persistentContainer = CoreDataManager.shared.persistentContainer
    var body: some Scene {
        WindowGroup {
            ContentView().environment(\.managedObjectContext,persistentContainer.viewContext)
        }
    }
}
